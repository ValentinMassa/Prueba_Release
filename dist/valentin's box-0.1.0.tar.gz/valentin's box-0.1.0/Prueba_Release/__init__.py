def saludar(nombre):
    return "Hola " + nombre + ", es mi primer paquete pip!"