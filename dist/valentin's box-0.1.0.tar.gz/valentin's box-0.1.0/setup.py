from setuptools import setup, find_packages

setup(
    name="Valentin's Box",                        
    version="0.1.0",                              
    packages=find_packages(),                       
    description="Un paquete pip simple de saludo", 
    author="Valentin Massa",                        
    author_email="valeenmassa2002@gmail.com",                
    url="https://github.com/ValentinMassa/Prueba_Release",     
)